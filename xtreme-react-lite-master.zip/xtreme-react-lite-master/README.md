# xtreme-react-lite

<a href="https://wrappixel.com">
<img src="https://wrappixel.com/wp-content/uploads/2017/03/wp-updated-logo.jpg" /></a>
<br/>

<h3>React Version of Xtreme admin, you can use it for your personal project, Footer backlink required, it must be redirect to our wrappixel.com</h3>

Check the live preview : 

<a href="https://wrappixel.com/demos/free-admin-templates/xtreme-reactadmin-lite/landingpage/">Demo </a>
